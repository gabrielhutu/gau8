#include <iostream>
#include <libssh/libssh.h>
#include <string>
#include <fstream>
#include <thread>
#include <vector>
#include <mutex>

void check_auth();

int main(int argc, char **argv)
{

    std::mutex file_lock;
    uint16_t port, timeout = 1;
    std::string host;
    bool run_thread = true;
    std::vector<std::thread*> threads;

    std::cout <<"   .oooooo.    o8o                                                          .oooooo.   oooo                            oooo        \n"
" d8P'  `Y8b   `\"'                                                         d8P'  `Y8b  `888                            `888        \n"
"888          oooo  oooo  oooo  ooo. .oo.  .oo.    .ooooo.   .oooooooo    888           888 .oo.    .ooooo.   .ooooo.   888  oooo  \n"
"888          `888  `888  `888  `888P\"Y88bP\"Y88b  d88' `88b 888' `88b     888           888P\"Y88b  d88' `88b d88' `\"Y8  888 .8P'   \n"
"888           888   888   888   888   888   888  888ooo888 888   888     888           888   888  888ooo888 888        888888.    \n"
"`88b    ooo   888   888   888   888   888   888  888    .o `88bod8P'     `88b    ooo   888   888  888    .o 888   .o8  888 `88b.  \n"
" `Y8bood8P'  o888o  `V88V\"V8P' o888o o888o o888o `Y8bod8P' `8oooooo.      `Y8bood8P'  o888o o888o `Y8bod8P' `Y8bod8P' o888o o888o \n"
"                                                           d\"     YD                                                              \n"
"                                                           \"Y88888P'                                                              \n" << std::endl;



    if(argc <= 3)
    {
        std::cout << "Usage " << argv[0] << " in_file_path out_file_path number_of_threads" << std::endl;
    }
    std::fstream in_file(argv[1]), out_file(argv[2]);
    
    std::cout << "Ce faci man, bagi la scan?\n" << std::endl;

    for(uint16_t i = 0; i < atoi(argv[3]); i++)
    {
        threads.push_back(new std::thread([&]{
            std::string ip;
            while(run_thread)
            {
                if(file_lock.try_lock())
                {
                    if(in_file >> host)
                    {
                        port = atoi(std::string(host.substr(host.find(":") + 1)).c_str());
                        ip = host.substr(0, host.find(":"));
                        file_lock.unlock();
                    }else
                    {
                        break;
                    }
                }
                ssh_session session = ssh_new();
                ssh_init();
                if(session == NULL)
                {
                    std::cerr << ssh_get_error(session);
                    return EXIT_FAILURE;
                }
                std::cout << "Testing Host " << host << std::endl;
                ssh_options_set(session, SSH_OPTIONS_HOST, ip.c_str());
                ssh_options_set(session, SSH_OPTIONS_PORT, &port);
                ssh_options_set(session, SSH_OPTIONS_TIMEOUT, &timeout);
                if(ssh_connect(session) != SSH_OK)
                {
                    std::cerr << ssh_get_error(session) << std::endl;
                }
                ssh_userauth_none(session, NULL);
                if( ssh_userauth_list(session, NULL) & SSH_AUTH_METHOD_PASSWORD )
                {
                    if(file_lock.try_lock())
                    {
                        out_file << host << std::endl;
                        std::cout << host << std::endl;
                        file_lock.unlock();
                    }
                }
                ssh_disconnect(session);
                ssh_free(session);
            }
        }));
    }

while(in_file.peek() != EOF)
{}

run_thread = false;

for(uint16_t i = 0; i < threads.size(); i++)
{
    std::cout << "Shuttind down thread " << threads[i]->get_id() << std::endl;
    threads[i]->join();
}
    return EXIT_SUCCESS;
}

